// script.js

// تهيئة اللغة الافتراضية
let currentLanguage = 'ar';

// دالة لتغيير اللغة
function changeLanguage(language) {
    currentLanguage = language;
    document.documentElement.lang = language;
    const translations = {
        ar: {
            loginTitle: "تسجيل الدخول",
            emailPlaceholder: "أدخل بريدك الإلكتروني",
            passwordPlaceholder: "أدخل كلمة المرور",
            loginButton: "تسجيل الدخول",
            createAccountButton: "إنشاء حساب",
            profileTitle: "الملف الشخصي",
            jobTitle: "عنوان الوظيفة",
            applyButton: "تقديم عرض",
            paymentTitle: "الدفع",
            cardNumberPlaceholder: "أدخل رقم البطاقة",
            expiryDatePlaceholder: "MM/YY",
            cvvPlaceholder: "أدخل CVV",
            processPaymentButton: "إجراء الدفع",
            messageSent: "تم إرسال الرسالة: ",
        },
        en: {
            loginTitle: "Login",
            emailPlaceholder: "Enter your email",
            passwordPlaceholder: "Enter your password",
            loginButton: "Login",
            createAccountButton: "Create Account",
            profileTitle: "Profile",
            jobTitle: "Job Title",
            applyButton: "Apply Now",
            paymentTitle: "Payment",
            cardNumberPlaceholder: "Enter Card Number",
            expiryDatePlaceholder: "MM/YY",
            cvvPlaceholder: "Enter CVV",
            processPaymentButton: "Process Payment",
            messageSent: "Message Sent: ",
        }
    };
}

function login() {
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    if (!email.checkValidity()) {
        document.getElementById("emailError").style.display = "block";
    } else if (!password.checkValidity()) {
        document.getElementById("passwordError").style.display = "block";
    } else {
        alert(`تم تسجيل الدخول بواسطة ${email.value}`);
    }
}

window.addEventListener("load", () => {
    setTimeout(() => {
        document.getElementById("splashScreen").style.display = "none";
        document.getElementById("loginScreen").style.display = "flex";
    }, 3000);
});
